// Lab report 2 - Group 13
// Alexy Pichette (100822470)
// Faisal Akbar (100846786)
// Mohammad Al-lozy (100829487)





#include "myshell.h"


void execute_command(char *input){
	char *token;
	char *delim = " \n";

	token = strtok(input, delim);
	
	if (token != NULL) {
	if (strcmp(token, "cd") == 0) {
		token = strtok(NULL, delim); // Get the directory path
		change_directory(token);
	} else {
		printf("Command not recognized.\n");
	}
}

}

int main() {
	char input[1024]; // buffers for user input

	while(1) {
		printf("MyShell> ");
		
		// read from user input
		if (fgets(input, sizeof(input), stdin) == NULL){
			break;
		}

		// execute the command
		execute_command(input);
	}

	return 0;
}
