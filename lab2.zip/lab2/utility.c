// Lab report 2 - Group 13
// Alexy Pichette (100822470)
// Faisal Akbar (100846786)
// Mohammad Al-lozy (100829487)



#include "myshell.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// function to change directory
void change_directory(char *path){
	
	if (path == NULL){
		char cwd[1024];
                if (getcwd(cwd, sizeof(cwd)) != NULL){
			printf("%s\n", cwd);
		} else {
			perror("getcwd() error");
		}
	} else { 
		// change to the specified directory
		if (chdir(path) != 0){
			perror("myshell");
		}
	}
}



