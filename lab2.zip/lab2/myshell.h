// Lab report 2 - Group 13
// Alexy Pichette (100822470)
// Faisal Akbar (100846786)
// Mohammad Al-lozy (100829487)



#ifndef MYSHELL_H
#define MYSHELL_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void change_directory(char *path); // for the cd function

#endif 
